

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center mt-1">
        <div class="col-md-8">
        <!-- Card -->
<div class="card">
    <!-- Card content -->
    <div class="card-body">
  
      <!-- Title -->
      <h1 class="card-title">Contáctenos</h1>
      <!-- Text -->
      <p>Elije cualquiera de estos medios y pronto un agente te estará contactando</p>
      <!-- Button -->
      <a href="<?php echo e(config('ajustes.redes.whatsapp')); ?>?text=" class="btn btn-success">WhatsApp</a>
      <a href="<?php echo e(config('ajustes.redes.facebook')); ?>" class="btn btn-primary">Facebook</a>
      <a href="mailto:<?php echo e(config('ajustes.sitio_web.correos.info')); ?>" class="btn btn-secondary"><?php echo e(config('ajustes.sitio_web.correos.info')); ?></a>
    </div>
  
  </div>
  <!-- Card -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/paginas/contactar.blade.php ENDPATH**/ ?>