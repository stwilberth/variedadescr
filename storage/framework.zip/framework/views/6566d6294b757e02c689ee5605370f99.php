
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Editar producto</h1>
    
            <form method="POST" action="/producto-update/<?php echo e($producto->slug); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

<!-------------Inputs--------------------->
                <div class="row mt-5">
                    <div class="col-md-6">
                        <div class="row">

                                <div class="form-group col-md-12">
                                        <label for="nombre">*Nombre:</label>
                                <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e($producto->nombre); ?>">
                                </div>

                                    <catalogo-c 
                                        marcas-lista="<?php echo e(json_encode($marcas)); ?>" 
                                        catalogo-lista="<?php echo e(json_encode($catalogo)); ?>"
                                        marca-selected="<?php echo e($producto->marca_id); ?>"
                                        modelo-selected="<?php echo e($producto->modelo); ?>"
                                        catalogo-selected="<?php echo e($producto->catalogo); ?>">
                                    </catalogo-c>

                                <genero-c></genero-c>

                                <div class="form-group col-md-6">
                                        <label for="stock">*Stock:</label>
                                        <input type="text" class="form-control" id="stock"  name="stock" value="<?php echo e($producto->stock); ?>">
                                </div>



                                <div class="form-group col-md-6">
                                    <?php
                                        $disponibilidad = config('options.disponibilidad');
                                        for ($i=0; $i < count($disponibilidad); $i++) { 
                                            if ($disponibilidad[$i]['value'] == $producto->disponibilidad) {
                                                $disponibilidad[$i]['selected'] = "selected";
                                            } else {
                                                $disponibilidad[$i]['selected'] = "";
                                            }
                                        }
                                    ?>
                                    <label for="disponibilidad">*Disponibilidad:</label>
                                    <select class="custom-select" name="disponibilidad" id="disponibilidad">
                                        <?php $__currentLoopData = $disponibilidad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item['value']); ?>" <?php echo e($item['selected']); ?>><?php echo e($item['nombre']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>



                                <div class="form-group col-md-6">
                                        <label for="codigo">Código:</label>
                                        <input type="text" class="form-control" id="codigo"  name="codigo" value="<?php echo e($producto->codigo); ?>">
                                </div> 

                        </div>
                    </div>
                    <div class="col-md-6">
                            <div class="row">
                                <div class="form-group col-md-6">
                                        <label for="moneda">*Moneda:</label>
                                    <select class="custom-select" name="moneda" id="moneda">
                                            <option selected value="1">¢</option>
                                            <option value="2">$</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-6">
                                        <label for="costo">*Costo:</label>
                                        <input type="text" class="form-control" id="costo"  name="costo" value="<?php echo e($producto->costo); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                        <label for="precio_venta">*Precio Venta:</label>
                                        <input type="text" class="form-control" id="precio_venta"  name="precio_venta" value="<?php echo e($producto->precio_venta); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="precio_mayorista">*Precio Mayorista:</label>
                                    <input type="text" class="form-control" id="precio_mayorista"  name="precio_mayorista" value="<?php echo e($producto->precio_mayorista); ?>">
                                </div>
                                <div class="form-group col-md-6">
                                        <label for="descuento">Descuento:</label>
                                        <input type="text" class="form-control" id="descuento" name="descuento" value="<?php echo e($producto->descuento); ?>">
                                </div>

                                <div class="form-group col-md-6">
                                        <label for="precio_anterior">Precio Anterior:</label>
                                        <input type="text" class="form-control" id="precio_anterior" name="precio_anterior" value="<?php echo e($producto->precio_anterior); ?>">
                                </div>

                                <div class="form-group col-md-6">
                                        <label for="precio_sugerido">Sugerido:</label>
                                        <input type="text" class="form-control" id="precio_sugerido" name="precio_sugerido" value="<?php echo e($producto->precio_sugerido); ?>">
                                </div>
<!-------------checkbox------------------->
                                <?php
                                function Checked($valor)
                                {
                                    if ($valor) {
                                        return "checked";
                                    }
                                }

                                    
                                ?>
                                <div class="form-group col-md-3">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" id="destacado" name="destacado" <?php echo e(Checked($producto->destacado)); ?> value="1"> Destacado
                                        </label>
                                    </div>
                                </div>                            

                                <div class="form-group col-md-3">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="publicado" <?php echo e(Checked($producto->publicado)); ?> value="1"> Publicado
                                        </label>
                                    </div>
                                </div>

                                <div class="checkbox col-md-3" style="margin-bottom:10px">
                                    <label>
                                        <input type="checkbox" name="oferta" id="oferta" <?php echo e(Checked($producto->oferta)); ?> value="1"> Es oferta.
                                    </label>
                                </div>

                                <div class="form-group col-md-6" v-show="reloj_create.oferta">
                                    <label for="fecha_inicio">Inicio de la oferta:</label>
                                    <input type="datetime-local" class="form-control" id="fecha_inicio" name="fecha_inicio" value="<?php echo e($producto->fecha_inicio); ?>">
                                </div>

                                <div class="form-group col-md-6" v-show="reloj_create.oferta">
                                    <label for="fecha_fin">Fin de la oferta:</label>
                                    <input type="datetime-local" class="form-control" id="fecha_fin" name="fecha_fin" value="<?php echo e($producto->fecha_fin); ?>">
                                </div>

                            </div>
                    </div>
                </div>
<!-------------Inputs fin--------------------->






<!-------------Descripcion--------------------->
                <div class="row">
                        <div class="col-md-12">
                                <div class="form-group">
                                        <label>*Descripción:</label>
                                        <textarea name="descripcion" id="descripcion" class="form-control" rows="3"><?php echo e($producto->descripcion); ?></textarea>
                                </div>
                        </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                            <div class="form-group">
                                    <label>*Descripción Redes sociales:</label>
                                    <textarea name="descripcion_social" id="descripcion_social" class="form-control" rows="2" maxlength="125"><?php echo e($producto->descripcion_social); ?></textarea>
                                    <em> Texto simple 125 carácteres máximo</em>
                            </div>
                    </div>
                    <div class="col-md-12">
                            <div class="form-group">
                                <label for="url_tiktok">Tiktok Video</label>
                                <textarea type="text" id="url_tiktok" name="url_tiktok" class="form-control" rows="6">
                                        <?php echo e($producto->url_tiktok); ?>

                                </textarea>
                            </div>
                    </div>
            </div>
<!-------------Descripcion fin--------------------->

                    <button type="submit" class="btn btn-success mt-4">Guardar</button>
                  </form>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdn.tiny.cloud/1/plgz9coqq9144skevnsvokxhwp5c676qqxsa0nf7rzi8iirk/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<script>
tinymce.init({
    selector:'#descripcion',  
    plugins: "lists emoticons",
    menubar: false,
    toolbar: 'undo redo | numlist bullist bold italic underline strikethrough | indent outdent aligncenter alignjustify alignright alignleft | fontselect emoticons'
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/productos/edit.blade.php ENDPATH**/ ?>