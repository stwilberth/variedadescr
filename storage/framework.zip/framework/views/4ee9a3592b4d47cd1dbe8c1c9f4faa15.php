
<!--Navbar-->
<nav class="navbar navbar-expand-lg navbar-dark default-color-dark">

        <!-- Navbar brand -->
        <a class="navbar-brand" href="/">VariedadesCR.com</a>
      
        <!-- Collapse button -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#basicExampleNav"
          aria-controls="basicExampleNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <!-- Collapsible content -->
        <div class="collapse navbar-collapse" id="basicExampleNav">
      
          <!-- Links -->
          <ul class="navbar-nav mr-auto">
            <!-- Dropdown -->
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">Catálogo</a>
              <div class="dropdown-menu dropdown-primary" aria-labelledby="navbarDropdownMenuLink">
                <a class="dropdown-item" href="/catalogo/relojes">Relojes</a>
                <a class="dropdown-item" href="/catalogo/perfumes">Perfumes</a>
              </div>
            </li>

            <?php $__currentLoopData = config('estructura.menus.principal'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                if ($item['url'] === Request::path()) {
                  $active = 'active';
                } else {
                  $active = '';
                }
            ?>
              <li class="nav-item <?php echo e($active); ?>">
                <a class="nav-link" href="/<?php echo e($item['url']); ?>"><?php echo e($item['nombre']); ?></a>
              </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php
              $isAdmin = false;
              if (Auth::check()) {
                $isAdmin = Auth::user()->AutorizaRoles('admin');
              }
              ?>
            <?php if($isAdmin): ?>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink" data-toggle="dropdown"
                  aria-haspopup="true" aria-expanded="false">Dashboard</a>
                <div class="dropdown-menu dropdown-primary" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="/home">Home</a>
                  <a class="dropdown-item" href="/producto-create">Agregar Producto</a>
                  <a class="dropdown-item" href="/users">Usuarios</a>
                  <a class="dropdown-item" href="/inventario">Inventario</a>
                  <a class="dropdown-item" href="/marcas">Marcas</a>
                </div>
              </li>
            <?php endif; ?>

          </ul>
          <!-- Links -->
          
          <ul class="navbar-nav ml-auto">
              <!-- Authentication Links -->
              <?php if(auth()->guard()->guest()): ?>
                  <li class="nav-item">
                      <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Iniciar sesion')); ?></a>
                  </li>
                  <?php if(Route::has('register')): ?>
                      <li class="nav-item">
                          <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrarme')); ?></a>
                      </li>
                  <?php endif; ?>
              <?php else: ?>
                  <li class="nav-item dropdown">
                      <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                          <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                      </a>

                      <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                             onclick="event.preventDefault();
                                           document.getElementById('logout-form').submit();">
                              <?php echo e(__('Salir')); ?>

                          </a>

                          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                              <?php echo csrf_field(); ?>
                          </form>
                          

                      </div>
                  </li>
              <?php endif; ?>
          </ul>
        </div>
        <!-- Collapsible content -->
</nav><?php /**PATH /home3/apren173/variedadescr.com/resources/views/blocks/navbar.blade.php ENDPATH**/ ?>