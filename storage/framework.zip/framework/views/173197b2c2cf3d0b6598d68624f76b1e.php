

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center m-5">
        <div class="col-md-8">
                <div class="card">
                        <div class="card-header">
                          Información
                        </div>
                        <div class="card-body">
                          <h5 class="card-title">Página no encontrada</h5>
                        </div>
             </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/errors/404.blade.php ENDPATH**/ ?>