
<?php $__env->startSection('content'); ?>
<div class="container"> 
<panel-admin slug-data=""></panel-admin>
<inven-comp productos-data="<?php echo e(json_encode($productos)); ?>"></inven-comp>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/productos/inventario.blade.php ENDPATH**/ ?>