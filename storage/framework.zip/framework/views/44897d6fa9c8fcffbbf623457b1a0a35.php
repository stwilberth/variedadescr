
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="container">
        <div class="row">
          
        </div>
    </div>
      
    <?php
        $lista = array(
            array('imgUrl' => 'img/relojes.jpg', 
                'titulo' => 'Relojes', 
                'url' => 'catalogo/relojes', 
                'style' => 'margin: 13%'
            ),
            array(
                'imgUrl' => 'img/perfumes.jpg', 
                'titulo' => 'Perfumes', 
                'url' => 'catalogo/perfumes', 
                'style' => 'margin-bottom: 13%; margin-left: 8%; margin-top: 13%;'
            )
        )
    ?>
    <div class="row mt-5">
        <?php for($i = 0; $i < count($lista); $i++): ?>

        <div class="col-6 d-none d-sm-none d-md-block">
            <div class="card card-image" style="background-image: url(<?php echo e($lista[$i]['imgUrl']); ?>);">
            <div class="text-white text-center d-flex align-items-center p-5 px-4" style="background-color: rgba(5, 29, 0, 0.79)">
                <div>
                <h3 class="card-title pt-2"><strong><?php echo e($lista[$i]['titulo']); ?></strong></h3>
                <p></p>
                <a class="btn btn-default" href="<?php echo e($lista[$i]['url']); ?>"><i class="fa fa-arrow-right" aria-hidden="true"></i>Ir</a>
                </div>
            </div>
            </div>
        </div>

        <div class="col-6 d-block d-sm-block d-md-none">
            <div class="card card-image" style="background-image: url(<?php echo e($lista[$i]['imgUrl']); ?>);">
            <div class="text-white" style="background-color: rgba(5, 29, 0, 0.79)">
            <h3 style="<?php echo e($lista[$i]['style']); ?>">
                    <a href="<?php echo e($lista[$i]['url']); ?>">
                        <strong style="color: white">
                            <i class="fa fa-arrow-right" aria-hidden="true"></i>
                            <?php echo e($lista[$i]['titulo']); ?> 
                        </strong>
                    </a>
                </h3>
            </div>
            </div>
        </div>

        <?php endfor; ?>
    </div>

    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slider-productos','data' => ['products' => $nixon,'titulo' => 'Relojes Nixon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider-productos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($nixon),'titulo' => 'Relojes Nixon']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slider-productos','data' => ['products' => $fossil,'titulo' => 'Relojes Fossil']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider-productos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($fossil),'titulo' => 'Relojes Fossil']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slider-productos','data' => ['products' => $invicta,'titulo' => 'Relojes Invicta']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider-productos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($invicta),'titulo' => 'Relojes Invicta']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slider-productos','data' => ['products' => $perfumes,'titulo' => 'Perfumes']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider-productos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($perfumes),'titulo' => 'Perfumes']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/welcome.blade.php ENDPATH**/ ?>