
    <?php $__env->startSection('meta_tags'); ?>
        <?php if($producto): ?>
            <title><?php echo e($producto->nombre); ?> | VariedadesCR.com</title>
            <meta property='article:published_time' content='<?php echo e($producto->created_at); ?>' />
            <meta property='article:section' content='event' />
            <?php if($producto->descripcion_social): ?>
                <meta name='description' itemprop='description' content='<?php echo e($producto->descripcion_social); ?>' />
                <meta property="og:description" content="<?php echo e($producto->descripcion_social); ?>" />
            <?php else: ?>
                <meta name='description' itemprop='description' content='<?php echo e($producto->descripcion); ?>' />
                <meta property="og:description" content="<?php echo e($producto->descripcion); ?>" />
            <?php endif; ?>
            <meta property="og:title" content="<?php echo e($producto->nombre); ?>" />
            <meta property="og:url" content="<?php echo e(url()->current()); ?>" />
            <meta property="og:type" content="article" />
            <meta property="og:locale" content="es-cr" />
            <meta property="og:locale:alternate" content="es-us" />
            <meta property="og:site_name" content="<?php echo e(config('ajustes.sitio_web.nombre')); ?>" />
            <?php if($producto->imagenes->count() > 0): ?>
            <meta property="og:image" content="https://variedadescr.com/storage/productos/<?php echo e($producto->imagenes->first()->ruta); ?>" />
            <meta property="og:image:secure_url" content="https://variedadescr.com/storage/productos/<?php echo e($producto->imagenes->first()->ruta); ?>" />   
            <?php endif; ?>
            <meta property="og:image:size" content="300" />
    
            <meta name="twitter:card" content="summary" />
            <meta name="twitter:title" content="<?php echo e($producto->nombre); ?>" />
            <meta name="twitter:site" content="@BrnBhaskar" />
        <?php endif; ?>
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $revendedor = (auth()->check() && auth()->user()->AutorizaRoles('revendedor'));
        $msj_whatsapp = "Me interesa este articulo.";
 

    switch ($producto->disponibilidad) {
        case 0:
            $disponibilidad = "Inmediata";
            $color_dispo = "text-success";
            break;

        case 1:
            $disponibilidad = "Una semana";
            $color_dispo = "text-success";
            break;

        case 2:
            $disponibilidad = "Dos semanas";
            $color_dispo = "text-success";
            break;

        case 3:
            $disponibilidad = "Agotado";
            $color_dispo = "text-danger";
            break;
        default:
            $disponibilidad = "";
            $color_dispo = "";
    }
    $agotado = false;
    $disableAgotado = '';
    if ($producto->stock == 0 || $producto->disponibilidad == 3) {
        $agotado = true;
        $disableAgotado = 'disabled';
    }
    ?>

    <div class="container">

        <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
                <?php echo e(session('status')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if($admin): ?>
            <panel-admin slug-data="<?php echo e($producto->slug); ?>"></panel-admin>
        <?php endif; ?>
        <div class="row mt-1 mb-1">
        </div>
        <div class="row">
            
            <div class="col-12 col-sm-6 mb-3">   
                <div class="row">
                    <div class="col-12">
                        <?php if($producto->imagenes->count() > 0): ?>
                        <div id="carousel-example-1z" class="carousel slide carousel-fade" data-ride="carousel">
                            <ol class="carousel-indicators">
                                <?php
                                    $active = 'active';
                                ?>
                                <?php for($i = 0; $i < $producto->imagenes->count(); $i++): ?>
                                    <li data-target="#carousel-example-1z" data-slide-to="<?php echo e($i); ?>" class="<?php echo e($active); ?>"></li>
                                    <?php
                                        $active = '';
                                    ?>
                                <?php endfor; ?>
                                <?php if($producto->url_tiktok): ?>
                                    <li data-target="#carousel-example-1z" data-slide-to="<?php echo e($producto->imagenes->count()); ?>"></li>
                                <?php endif; ?>
                            </ol>
                            <div class="carousel-inner" role="listbox">
                                <?php
                                    $active = 'active';
                                ?>
                                <?php $__currentLoopData = $producto->imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <div class="carousel-item <?php echo e($active); ?>">
                                        <a href="/storage/productos/<?php echo e($imagen->ruta); ?>" data-lightbox="roadtrip">
                                            <img class="d-block w-100" src="/storage/productos/<?php echo e($imagen->ruta); ?>" alt="First slide">
                                        </a>
                                    </div>
                                    <?php
                                        $active = '';
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($producto->url_tiktok): ?>
                                    <div class="carousel-item">
                                        <?php echo $producto->url_tiktok; ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <a class="carousel-control-prev" href="#carousel-example-1z" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carousel-example-1z" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>  
                        <?php else: ?>
                            <img src="/img/sin_foto.png" alt="Producto sin imagen">
                        <?php endif; ?>
                    </div>
                </div>

                <?php if($producto->imagenes->count() > 0): ?>
                <div class="row mt-5">
                    <div class="col-12 text-center">
                        <?php $__currentLoopData = $producto->imagenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $imagen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img 
                                    src="/storage/productos/<?php echo e($imagen->ruta); ?>" 
                                    alt="<?php echo e($producto->nombre); ?>" 
                                    data-target="#carousel-example-1z" 
                                    data-slide-to="<?php echo e($i); ?>" 
                                    class="img-thumbnail" 
                                    style="height: 100px; width:100px; margin-left:2%; margin-top:1%">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($producto->url_tiktok): ?>
                            <img 
                                src="/img/tik-tok.png" 
                                alt="tiktok" 
                                data-target="#carousel-example-1z" 
                                data-slide-to="<?php echo e($producto->imagenes->count()); ?>" 
                                class="img-thumbnail" 
                                style="height: 100px; width:100px; margin-left:2%; margin-top:1%">
                        <?php endif; ?>
                    </div>
                </div> 
                <?php endif; ?>

            </div>
            
            <div class="col-12 col-sm-6 mb-3">
                <div class="row">
                    <div class="col-12 mb-3">
                        <h1><?php echo e($producto->nombre); ?></h1>
                    </div>
                    
                    <div class="col-12 pl-4 pr-4">
                        <div class="row">
                            <div class="col-12">
                                <?php if($producto->publicado == 0): ?>
                                    <h2 class="red-text">No publicado</h2>
                                <?php endif; ?>
                            </div>
                            <div class="col-12 col-sm-6">
                                <span class="font-weight-bold">Marca:</span>
                                <a href="/catalogo/relojes?marca=<?php echo e($producto->marca->id); ?>&genero=0" class="text-blue">
                                    <?php echo e($producto->marca->nombre); ?>.
                                </a>
                                <br>
                                <span class="font-weight-bold">Modelo:</span> <?php echo e($producto->modelo); ?>.
                                <br>
                                <span class="font-weight-bold">Género:</span>
                                <a href="/catalogo/relojes?marca=0&genero=<?php echo e($producto->genero); ?>" class="text-blue">
                                    <?php echo e($producto->generoTexto); ?>.
                                </a>
                                <br>
                                <span class="font-weight-bold">Disponibilidad:</span> <span class="<?php echo e($color_dispo); ?>"><?php echo e($disponibilidad); ?>.</span>
                                <br>
                                <span class="font-weight-bold">Stock:</span> <?php echo e($producto->stock); ?>.
                            </div>
                            <div class="col-12 col-sm-6 mt-3">
                                <a href="<?php echo e(config('ajustes.redes.whatsapp')); ?>?text=<?php echo e(Request::url()); ?> <?php echo e($msj_whatsapp); ?>" class="btn btn-success btn-lg btn-block" style="border-radius:30px">
                                    <span style="font-size:1rem">Pedir</span>
                                    <i class="fa fa-whatsapp fa-5"></i> 
                                </a>
                            </div>
                        </div>
                        <div class="row mt-4">
                            <div class="col">
                                <span class="font-weight-bold"></span>
                                 <span class="font-weight-bold" style="color: #d5312c; font-size: 25px">
                                    <?php echo e($producto->currency_symbol); ?>

                                    <?php if($revendedor): ?>
                                        <?php echo e($producto->precio_mayorista); ?>

                                    <?php else: ?>
                                        <?php echo e($producto->precio_venta); ?>

                                    <?php endif; ?>
                                </span>
                                <?php if($admin): ?>
                                    <br>
                                    Mayorista:
                                    <?php echo e($producto->currency_symbol); ?><?php echo e($producto->precio_mayorista); ?>

                                <?php endif; ?>
                                <br>
                                <?php if($producto->precio_anterior): ?>
                                <span class="font-weight-bold" style="color: #8a8a8a;" >Antes:</span> <span style="color: #8a8a8a; textDecoration: line-through; font-family: georgia,sans-serif"><?php echo e($producto->currency_symbol); ?><?php echo e($producto->precio_anterior); ?>.</span> 
                                <br>
                                <?php endif; ?>
                            </div>
                            <div class="col">
                                <?php if($producto->precio_sugerido): ?>
                                    <span class="font-weight-bold" style="color: #8a8a8a;">Precio sugerido:</span><span style="font-family: georgia,sans-serif; color: #8a8a8a;"> <?php echo e($producto->currency_symbol); ?><?php echo e($producto->precio_sugerido); ?>.</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mt-4">
                                <div class="col-12 col-sm-12"><?php echo $producto->descripcion; ?></div>
                        </div>
                        
                        <div class="row mt-4">
                            <div class="col-12 text-center">
                                <a href="http://www.facebook.com/sharer/sharer.php?u=<?php echo e(url()->current()); ?>" target="_blank" class="btn primary-color-dark text-white">
                                    <i class="fa fa-facebook fa-lg"></i>
                                </a>
                                <a href="https://twitter.com/share?ref_src=twsrc%5Etfw" target="_blank" class="btn info-color text-white" data-show-count="false">
                                    <i class="fa fa-twitter fa-lg"></i>
                                </a>
                                <a href="whatsapp://send?text=<?php echo e(url()->current()); ?>" target="_blank" class="btn btn-success text-white">
                                    <i class="fa fa-whatsapp fa-lg"></i>
                                </a>
                            </div>
                        </div>
        
                    </div>
    
                </div>
            </div>
          
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slider-productos','data' => ['products' => $more_products,'titulo' => 'Más relojes '. $producto->marca->nombre]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider-productos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($more_products),'titulo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Más relojes '. $producto->marca->nombre)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slider-productos','data' => ['products' => $new_products,'titulo' => 'Nuevos productos']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider-productos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['products' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($new_products),'titulo' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Nuevos productos')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.11.1/js/lightbox.min.js" defer></script>
<script async src="https://www.tiktok.com/embed.js"></script>

<script>
    $(document).ready(function(){
    $('.carousel').carousel({
        interval: false
    });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/productos/show.blade.php ENDPATH**/ ?>