<div class="row">
    <a href="<?php echo e(config('ajustes.redes.whatsapp')); ?>?text=" class="btn btn-link p-0"><img src="/img/whatsapp_icono.png" alt="Icono Whatsapp" style="width:40px; height:40px">+506-87811054</a>
    <a href="mailto:<?php echo e(config('ajustes.sitio_web.correos.info')); ?>" class="btn btn-link p-0 mt-3"><?php echo e(config('ajustes.sitio_web.correos.info')); ?></a>
</div><?php /**PATH /home3/apren173/variedadescr.com/resources/views/blocks/contactar_barra.blade.php ENDPATH**/ ?>