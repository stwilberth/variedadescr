<?php if(isset($products) && $products->count() > 3): ?>
  <?php
      // sirve para hacer los productos en grupos de 4
      $groups = array();
      $gruposDe4 = array();
      $conteoDe4 = 0;
      for($i = 0; $i < count($products); ++$i) {
        $conteoDe4 = $conteoDe4 + 1;
        if ($conteoDe4 <= 4) {
          array_push($gruposDe4, $products[$i]);
        } else {
          array_push($groups, $gruposDe4);
          $gruposDe4 = array();
          $conteoDe4 = 0;
        }
      }
      //crear id unico con timestap aleatorio para el slider y convertirlo en letras
      $sliderid = str_shuffle(strtotime("now") . rand(1, 10000));
      //convertir $sliderid en letras
      $sliderid = base_convert($sliderid, 10, 36);
  ?>

    <div class="row mt-5">
      <div class="col-12">  
        <h2>
          <strong>
              <?php echo e($titulo); ?>

          </strong> 
        </h2>     
      </div>
    </div>

  <div class="container">
    <div class="row">


      <div class="col-12 d-none d-sm-none d-md-block">
        <div id="<?php echo e($sliderid); ?>" class="carouselreloj carousel slide" data-ride="carousel" data-interval="0">
          <ol class="carousel-indicators">
            <?php
                $active = 'active';
            ?>
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li data-target="#<?php echo e($sliderid); ?>" data-slide-to="<?php echo e($key); ?>" class="<?php echo e($active); ?>"></li>
              <?php
                  $active = '';
              ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ol>
          <div class="carousel-inner">
            <?php
                $active = 'active';
            ?>
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="item carousel-item <?php echo e($active); ?>">
                <div class="row">  
                  <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                      $msj_whatsapp = "Me interesa este articulo.";
                    ?>
                    <div class="col-md-3">
                      <div class="thumb-wrapper">
                        <div class="img-box">
                          <?php if($producto->imagenes->count() > 0): ?>
                            <a href="/catalogo/relojes/<?php echo e($producto->slug); ?>">   
                              <img src="/storage/productos/thumb_<?php echo e($producto->imagenes->first()->ruta); ?>" class="img-responsive img-fluid" alt="Fotografia de <?php echo e($producto->nombre); ?>">
                            </a>
                          <?php else: ?>
                            <a href="/catalogo/relojes/<?php echo e($producto->slug); ?>">   
                              <img src="/img/sin_foto.png" class="card-img-top" alt="Producto sin imagen"> 
                            </a>
                          <?php endif; ?>
                        </div>
                        <div class="thumb-content">
                          <h4><?php echo e($producto->nombre); ?></h4>
                          <p class="item-price"><span><?php echo e($producto->currency_symbol); ?><?php echo e($producto->precio_venta); ?></span></p>
                          <a href="/catalogo/relojes/<?php echo e($producto->slug); ?>" class="btn btn-sm m-0 ml-1 stylish-color mdb-color white-text pl-3 pr-3">&nbsp;Ver&nbsp;</a>
                          <a href="https://wa.me/+50687811054?text=https://variedadescr.com/catalogo/relojes/<?php echo e($producto->slug); ?> <?php echo e($msj_whatsapp); ?>" class="btn btn-default btn-sm m-0 pl-3 pr-3">Pedir</a>
                        </div>						
                      </div>
                    </div> 
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
              </div>
              <?php
                  $active = '';
              ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <a class="carousel-control left carousel-control-prev" href="#<?php echo e($sliderid); ?>" data-slide="prev">
            <i class="fa fa-angle-left"></i>
          </a>
          <a class="carousel-control right carousel-control-next" href="#<?php echo e($sliderid); ?>" data-slide="next">
            <i class="fa fa-angle-right"></i>
          </a>
        </div>
      </div>

      <div class="col-12 d-block d-sm-block d-md-none">

        <div id="<?php echo e($sliderid); ?>_movil" class="carouselreloj carousel slide" data-ride="carousel" data-interval="0">
          <div class="carousel-inner">
            <?php
                $active = 'active';
            ?>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="item carousel-item <?php echo e($active); ?>">
                <div class="row">  
                    <?php
                      $msj_whatsapp = "Me interesa este articulo.";
                    ?>
                    <div class="col-12">
                      <div class="thumb-wrapper">
                        <div class="img-box">
                          <?php if($producto->imagenes->count() > 0): ?>
                            <a href="/catalogo/relojes/<?php echo e($producto->slug); ?>">   
                              <img src="/storage/productos/thumb_<?php echo e($producto->imagenes->first()->ruta); ?>" class="img-responsive img-fluid" alt="Fotografia de <?php echo e($producto->nombre); ?>">
                            </a>
                          <?php else: ?>
                            <a href="/catalogo/relojes/<?php echo e($producto->slug); ?>">   
                              <img src="/img/sin_foto.png" class="card-img-top" alt="Producto sin imagen"> 
                            </a>
                          <?php endif; ?>
                        </div>
                        <div class="thumb-content">
                          <h4><?php echo e($producto->nombre); ?></h4>
                          <p class="item-price"><span><?php echo e($producto->currency_symbol); ?><?php echo e($producto->precio_venta); ?></span></p>
                          <a href="/catalogo/relojes/<?php echo e($producto->slug); ?>" class="btn btn-sm m-0 ml-1 stylish-color mdb-color white-text pl-3 pr-3">&nbsp;Ver&nbsp;</a>
                          <a href="https://wa.me/+506-87811054?text=https://variedadescr.com/catalogo/relojes/<?php echo e($producto->slug); ?> <?php echo e($msj_whatsapp); ?>" class="btn btn-default btn-sm m-0 pl-3 pr-3">Pedir</a>
                        </div>						
                      </div>
                    </div> 
                </div>
              </div>
              <?php
                  $active = '';
              ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <a class="carousel-control left carousel-control-prev" href="#<?php echo e($sliderid); ?>_movil" data-slide="prev">
            <i class="fa fa-angle-left"></i>
          </a>
          <a class="carousel-control right carousel-control-next" href="#<?php echo e($sliderid); ?>_movil" data-slide="next">
            <i class="fa fa-angle-right"></i>
          </a>
        </div>
      </div>
      

    </div>
  </div>
<?php endif; ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/components/slider-productos.blade.php ENDPATH**/ ?>