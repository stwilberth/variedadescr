
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Crear un producto</h1>
            <form method="POST" action="/producto-store" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
<!-------------Inputs--------------------->
                <?php if($errors->any()): ?>
                <div class="row">

                        <div class="alert alert-danger" role="alert">
                                <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                        </div>                      
                </div>
                <?php endif; ?>
                <div class="row mt-5">
                    <div class="col-md-6">
                        <div class="row">

                                <div class="form-group col-md-12">
                                        <?php
                                                $isInvalid = ($errors->first('nombre'))?'is-invalid':'';
                                        ?>
                                        <label for="nombre">*Nombre:</label>
                                        <input type="text" class="form-control <?php echo e($isInvalid); ?>" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>" required>
                                        <?php echo $errors->first('nombre', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>

                                <catalogo-c 
                                        marcas-lista="<?php echo e(json_encode($marcas)); ?>" 
                                        catalogo-lista="<?php echo e(json_encode($catalogo)); ?>"
                                        marca-selected="<?php echo e(old('marca')); ?>"
                                        modelo-selected="<?php echo e(old('modelo')); ?>"
                                        catalogo-selected="<?php echo e(old('catalogo')); ?>">
                                </catalogo-c>

                                <genero-c></genero-c>

                                <div class="form-group col-md-6">
                                        <?php
                                                $isInvalid = ($errors->first('stock'))?'is-invalid':'';
                                        ?>
                                        <label for="stock">*Stock:</label>
                                        <input type="number" class="form-control <?php echo e($isInvalid); ?>" id="stock" name="stock" value="<?php echo e(old('stock')); ?>" required>
                                        <?php echo $errors->first('stock', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>

                                <div class="form-group col-md-6">
                                        <?php
                                                $isInvalid = ($errors->first('disponibilidad'))?'is-invalid':'';
                                        ?>
                                        <label for="disponibilidad">*Disponibilidad:</label>
                                        <select class="custom-select <?php echo e($isInvalid); ?>" name="disponibilidad" id="disponibilidad">
                                                <option  selected value="1">Inmediata</option>
                                                <option value="2">Una semana</option>
                                                <option value="3">Dos semanas</option>
                                                <option value="4">Agotado</option>
                                        </select>
                                        <?php echo $errors->first('disponibilidad', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>

                                <div class="form-group col-md-6">
                                        <?php
                                                $isInvalid = ($errors->first('codigo'))?'is-invalid':'';
                                        ?>
                                        <label for="codigo">Código:</label>
                                        <input type="text" class="form-control <?php echo e($isInvalid); ?>" id="codigo" name="codigo" value="<?php echo e(old('codigo')); ?>">
                                        <?php echo $errors->first('codigo', '<div class="invalid-feedback">:message</div>'); ?>

                                </div> 

                        </div>
                    </div>
                    <div class="col-md-6">
                            <div class="row">
                                <div class="form-group col-md-6">
                                        <?php
                                                $isInvalid = ($errors->first('moneda'))?'is-invalid':'';
                                        ?>
                                        <label for="moneda">*Moneda:</label>
                                        <select class="custom-select <?php echo e($isInvalid); ?>" name="moneda" id="moneda" required>
                                            <option value="1">¢</option>
                                            <option value="2">$</option>
                                        </select>
                                        <?php echo $errors->first('moneda', '<div class="invalid-feedback">:message</div>'); ?>


                                </div>
                                <div class="form-group col-md-6">
                                        <?php
                                                $isInvalid = ($errors->first('costo'))?'is-invalid':'';
                                        ?>
                                        <label for="costo">*Costo:</label>
                                        <input type="number" class="form-control <?php echo e($isInvalid); ?>" id="costo" name="costo" value="<?php echo e(old('costo')); ?>" required>
                                        <?php echo $errors->first('costo', '<div class="invalid-feedback">:message</div>'); ?>


                                </div>
                                <div class="form-group col-md-6">
                                        <?php
                                                $isInvalid = ($errors->first('precio_mayorista'))?'is-invalid':'';
                                        ?>
                                        <label for="precio_venta">*Precio Mayorista:</label>
                                        <input type="number" class="form-control <?php echo e($isInvalid); ?>" 
                                                id="precio_mayorista" 
                                                name="precio_mayorista" 
                                                value="<?php echo e(old('precio_mayorista')); ?>" 
                                                required>
                                        <?php echo $errors->first('precio_mayorista', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                                <div class="form-group col-md-6">
                                        <?php
                                                $isInvalid = ($errors->first('precio_venta'))?'is-invalid':'';
                                        ?>
                                        <label for="precio_venta">*Precio Venta:</label>
                                        <input type="number" class="form-control <?php echo e($isInvalid); ?>" id="precio_venta" name="precio_venta" value="<?php echo e(old('precio_venta')); ?>" required>
                                        <?php echo $errors->first('precio_venta', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                                <div class="form-group col-md-6">
                                        <label for="descuento">Descuento:</label>
                                        <input type="number" class="form-control" id="descuento" name="descuento" value="<?php echo e(old('descuento')); ?>">
                                        <?php echo $errors->first('descuento', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>

                                <div class="form-group col-md-6">
                                        <label for="precio_anterior">Precio Anterior:</label>
                                        <input type="number" class="form-control" id="precio_anterior" name="precio_anterior" value="<?php echo e(old('precio_anterior')); ?>">
                                        <?php echo $errors->first('precio_anterior', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>

                                <div class="form-group col-md-6">
                                        <label for="precio_sugerido">Precio Sugerido:</label>
                                        <input type="number" class="form-control" id="precio_sugerido" name="precio_sugerido" value="<?php echo e(old('precio_sugerido')); ?>">
                                        <?php echo $errors->first('precio_sugerido', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>

                                <div class="form-group col-md-3">
                                                <div class="checkbox" v-show="false">
                                                        <label>
                                                            <input type="checkbox" id="destacado" name="destacado"> Destacado
                                                        </label>
                                                 </div>
                                        </div>                            

                                        <div class="form-group col-md-3">
                                            <div class="checkbox">
                                                <label>
                                                    <input type="checkbox" checked name="publicado"> Publicado
                                                </label>
                                            </div>
                                        </div>
            
                                        <div class="checkbox col-md-3" style="margin-bottom:10px" v-show="false">
                                                <label>
                                                        <input type="checkbox" name="oferta" id="oferta" value="false" v-model="reloj_create.oferta" v-show="false"> Es oferta.
                                                </label>
                                        </div>


                                        <div class="form-group col-md-6" v-show="reloj_create.oferta">
                                            <label for="fecha_inicio">Inicio de la oferta:</label>
                                            <input type="datetime-local" class="form-control" id="fecha_inicio" name="fecha_inicio">
                                        </div>
                                        <div class="form-group col-md-6" v-show="reloj_create.oferta">
                                                <label for="fecha_fin">Fin de la oferta:</label>
                                                <input type="datetime-local" class="form-control" id="fecha_fin" name="fecha_fin">
                                        </div>

                            </div>
                    </div>
                </div>
<!-------------Inputs fin--------------------->






<!-------------Descripcion--------------------->
                <div class="row">
                        <div class="col-md-12">
                                <div class="form-group">
                                        <?php
                                                $isInvalid = ($errors->first('descripcion'))?'is-invalid':'';
                                        ?>
                                        <label>*Descripción:</label>
                                        <textarea name="descripcion" id="descripcion" class="form-control <?php echo e($isInvalid); ?>" rows="3"><?php echo e(old('descripcion')); ?></textarea>
                                        <?php echo $errors->first('descripcion', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                        </div>
                </div>
                <div class="row">
                        <div class="col-md-12">
                                <div class="form-group">
                                        <?php
                                                $isInvalid = ($errors->first('descripcion_social'))?'is-invalid':'';
                                        ?>
                                        <label>*Descripción Redes sociales:</label>
                                        <textarea name="descripcion_social" id="descripcion_social" class="form-control <?php echo e($isInvalid); ?>" rows="2" maxlength="125" required><?php echo e(old('descripcion_social')); ?></textarea>
                                        <em> Texto simple 125 carácteres máximo</em>
                                        <?php echo $errors->first('descripcion_social', '<div class="invalid-feedback">:message</div>'); ?>

                                </div>
                        </div>
                        <div class="col-md-12">
                                <div class="form-group">
                                        <label for="url_tiktok">Tiktok Video</label>
                                        <textarea type="text" id="url_tiktok" name="url_tiktok" class="form-control" rows="6">
                                                <?php echo e(old('url_tiktok')); ?>

                                        </textarea>
                                </div>
                        </div>
                </div>
<!-------------Descripcion fin--------------------->


                    <button type="submit" class="btn btn-success mt-4">Guardar</button>
                  </form>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdn.tiny.cloud/1/plgz9coqq9144skevnsvokxhwp5c676qqxsa0nf7rzi8iirk/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<script>
tinymce.init({
        selector:'#descripcion',  
        plugins: "lists emoticons",
        menubar: false,
        toolbar: 'undo redo | numlist bullist bold italic underline strikethrough | indent outdent aligncenter alignjustify alignright alignleft | fontselect emoticons'
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/productos/create.blade.php ENDPATH**/ ?>