
<?php $__env->startSection('content'); ?>
<div class="container mt-5">

        <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
                <?php echo e(session('status')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger alert-dismissible fade show mt-2" role="alert">
                <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

    <h1>Marcas</h1>
    <div class="row mb-3">

        <div class="col-md-12">
            <div class="card mt-4 mb-4">
                <div class="card-body">
                    <h5 class="card-title">Agregar Marca:</h5>
                    <form class="form-row" method="POST" action="/marcas">
                        <?php echo csrf_field(); ?>
                        <div class="col-6">
                            <input type="text" class="form-control" id="inlineFormInputName2" placeholder="Nombre Marca" name="nombre">
                        </div>
                        <div class="col-4">
                            <select id="inputState" class="custom-select" name="catalogo" placeholder="Catálogo">
                                <?php $__currentLoopData = $catalogo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-2">
                            <button type="submit" class="btn btn-primary btn-md mt-0">Agregar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <h2>Relojes</h2>
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Cantidad Productos</th>
                        <th scope="col">Editar</th>
                        <th scope="col">Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $relojes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($marca->id); ?></th>
                            <td><?php echo e($marca->nombre); ?></td>
                            <td><?php echo e($marca->productos->count()); ?></td>
                            <td><a href="/marcas/<?php echo e($marca->id); ?>/edit" class="btn btn-link">Editar</a></td>
                            <td>
                                <form action="/marcas/<?php echo e($marca->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-link" style="color:tomato" <?php if($marca->productos->count() > 0 ): ?> disabled <?php endif; ?>>X</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <h2>Perfumes</h2>
        <div class="col-md-12">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Cantidad Productos</th>
                        <th scope="col">Editar</th>
                        <th scope="col">Eliminar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $perfumes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($marca->id); ?></th>
                            <td><?php echo e($marca->nombre); ?></td>
                            <td><?php echo e($marca->productos->count()); ?></td>
                            <td><a href="/marcas/<?php echo e($marca->id); ?>/edit" class="btn btn-link">Editar</a></td>
                            <td>
                                <form action="/marcas/<?php echo e($marca->id); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-link" style="color:tomato" <?php if($marca->productos->count() > 0 ): ?> disabled <?php endif; ?>>X</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/marcas/index.blade.php ENDPATH**/ ?>