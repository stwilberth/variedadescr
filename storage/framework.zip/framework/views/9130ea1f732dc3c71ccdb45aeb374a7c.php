
<?php $__env->startSection('content'); ?>
<div class="container"> 
    
        <div class="row">
            <form action="<?php echo e(route('catalogoIndex', $catalogo_slug)); ?>" method="GET" class="col-12 p-0">
                
                <div class="row ml-3 mb-3">
                    <div class="col-4 col-md-2 p-0 mt-2">
                        <select id="inputState" class="custom-select" name="marca">
                            <option value="0">Marcas</option>
                            <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->cantidad > 0): ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if($marca_id == $item->id): ?> selected <?php endif; ?> >
                                        <?php echo e($item->nombre); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-4 col-md-2 p-0 ml-2 mt-2">
                        <select id="inputState" class="custom-select" name="genero">
                            <?php $__currentLoopData = config('options.generos'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item['value']); ?>" <?php if($item['value'] == $genero): ?> selected <?php endif; ?>><?php echo e($item['nombre']); ?></option>   
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-3 p-1">
                        <button type="submit" class="btn btn-success p-2  mt-1" style="color: #fff">Filtrar</button>
                    </div>
                </div>
            </form>
        </div>
    

    <?php if(auth()->user() && auth()->user()->AutorizaRoles('admin')): ?>
        <panel-admin slug-data=""></panel-admin>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show mt-2" role="alert">
        <?php echo e(session('status')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
    <?php endif; ?>

    
    <?php if(count($productos)<=0): ?>
        <div class="row">
            <div class="col-12">
                <div class="row d-flex justify-content-center">
                    <div class="alert alert-warning alert-dismissible fade show mt-2" role="alert">
                            La consulta no generó resultados.
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
        
            <div class="col-12">
                <h1 class="text-center"><?php echo e($title); ?></h1>
            </div>

            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $msj_whatsapp = "Me interesa este articulo.";
                ?>
                
                <div class="col-6 col-md-3 mt-5">
                    <!-- Card -->
                    <div class="m-0 text-center">        
                        <!-- Card image -->
                        <?php if($producto->imagenes->count() > 0): ?>
                            <a href="/catalogo/<?php echo e($producto->catalogoM->slug); ?>/<?php echo e($producto->slug); ?>">
                                <img class="card-img-top" loading="lazy" src="/storage/productos/thumb_<?php echo e($producto->imagenes->first()->ruta); ?>" alt="Fotograía del <?php echo e($producto->nombre); ?>"> 
                                <?php
                                    // Obtén la fecha de creación del producto (de tu modelo, supongamos que es una propiedad llamada 'created_at')
                                    $fechaCreacion = strtotime($producto->created_at);
                                    // Calcula la fecha límite (hace un mes)
                                    $fechaLimite = strtotime('-1 month');
                                    // Compara las fechas
                                    $productoAntiguo = $fechaCreacion < $fechaLimite;
                                ?>

                                <?php if($producto->nuevo && !$productoAntiguo): ?>
                                    <img class="card-img-top nuevo-etiqueta" loading="lazy" src="/img/nuevo.png"> 
                                <?php endif; ?>
                            </a>   
                        <?php else: ?>
                        <a href="/catalogo/<?php echo e($producto->catalogoM->slug); ?>/<?php echo e($producto->slug); ?>">
                            <img class="card-img-top" loading="lazy" src="/img/sin_foto.png" alt="Fotografía del <?php echo e($producto->nombre); ?>">     
                        </a>
                        <?php endif; ?>   
                        <!-- Card content -->
                        <div class="text-center">          
                            <!-- Title -->
                            <h6 class="card-title mt-2 text-truncate"><?php echo e($producto->nombre); ?></h6>
                            <?php if($producto->publicado == 0): ?>
                                <h6 class="red-text">No publicado</h6>
                            <?php endif; ?>
                            <!-- Text -->
                            <span style="font-size:1.2rem; color: #86bd57;">
                                <?php if(auth()->user() && auth()->user()->AutorizaRoles('revendedor')): ?>
                                    <?php if($producto->precio_mayorista): ?>
                                        <?php echo e($producto->moneda_simbolo); ?><?php echo e($producto->precio_mayorista); ?>

                                    <?php else: ?>
                                        No disponible
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php echo e($producto->moneda_simbolo); ?><?php echo e($producto->precio_venta); ?>

                                <?php endif; ?>
                            </span>
                            <?php if(false): ?>
                                <span style="font-size:1rem;textDecoration: line-through"><?php echo e($producto->moneda_simbolo); ?><?php echo e($producto->precio_anterior); ?></span>
                            <?php endif; ?>
                            <br>
                            <!-- Button -->
                            <a  href="/catalogo/<?php echo e($producto->catalogoM->slug); ?>/<?php echo e($producto->slug); ?>" 
                                class="btn btn-sm stylish-color mdb-color white-text" style="padding-left: 15px; padding-right:15px">Ver</a>
                            <a href="<?php echo e(config('ajustes.redes.whatsapp')); ?>?text=https://variedadescr.com/catalogo/<?php echo e($producto->catalogoM->slug); ?>/<?php echo e($producto->slug); ?> <?php echo e($msj_whatsapp); ?>" 
                                class="btn btn-default btn-sm" style="padding-left: 10px; padding-right:10px">Pedir</a>        
                        </div>
                    </div>
                </div>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    

    



    

    
        
    

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home3/apren173/variedadescr.com/resources/views/productos/index.blade.php ENDPATH**/ ?>